package cz.cvut.eshopwizard.tree;


public class ClassicProcessor extends Processor {

    public ClassicProcessor(String name, int price, int energyImport) {
        super(name, price, energyImport);
    }
    
}
