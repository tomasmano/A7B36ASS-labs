package cz.cvut.eshopwizard.tree;


public class ModernProcessor extends Processor {

    public ModernProcessor(String name, int price, int energyImport) {
        super(name, price, energyImport);
    }
    
}
